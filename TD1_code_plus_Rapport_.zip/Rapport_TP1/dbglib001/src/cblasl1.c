#include <cblasl1.h>
#include <stddef.h>  // Pour NULL
#include <stdio.h>   // Pour fprintf et stderr

/*
 * Routines of cblas level 1
 */

void sswap(const int size, float *x, const int incx, float *y, const int incy)
{
	if ( (incx == 1) && (incy == 1) )
	{
		for (int i=0; i<size; ++i)
		{
			float tmp;
			tmp = x[i];
			x[i] = y[i];
			y[i] = tmp;
		}
	}
	else
	{
 
	  int ix = 0;
	  int iy = 0;
		for (int i=0; i<size; ++i)
		{

			float tmp;
			tmp = x[ix];
			x[ix] = y[iy];
			y[iy] = tmp;
			ix = ix + incx;
			iy = iy + incy;
		}
	}
}
//ERR
/*
void scopy(const int size, const float *x, const int incx, float *y, const int incy)
{
	if ( (incx == 1) && (incy == 1) )
	{
		for (int i=0; i<=size; ++i) Ligne � corrig� (ligne 41 avant la correction)
		{
			y[i] = x[i];      
		}
	}
	else
	{
		int ix = 0;
		int iy = 0;
		for (int i=0; i<=size; ++i)
		{
			y[iy] = x[ix];
			ix = ix + incx;
			iy = iy + incy;
		}
	}
}*/      
void scopy(const int size, const float *x, const int incx, float *y, const int incy)
{
	if ( (incx == 1) && (incy == 1) )
	{
    for (int i = 0; i < size; ++i) {  // i < size assure qu'on reste dans les limites
      y[i] = x[i];
    }
	}
	else
	{
		int ix = 0;
		int iy = 0;
		for (int i=0; i<=size; ++i)
		{
			y[iy] = x[ix];
			ix = ix + incx;
			iy = iy + incy;
		}
	}
}
//Copie chaque �l�ment du vecteur x dans y.







//ERR
/*
void saxpy(const int size, const float alpha, const float *x, const int incx, float *y, const int incy)
{

	if ( (incx == 1) && (incy == 1) )
	{
		for (int i=0; i<=size; ++i)  Ligne � corrig� (ligne 64 avant la correction)
		{
			y[i] = y[i] + alpha * x[i];
		}
	}
	else
	{
		int ix = 0;
		int iy = 0;
		for (int i=0; i<=size; ++i)
		{
			y[i] = y[i] + alpha * x[i];
			ix = ix + incx;
			iy = iy + incy;
		}
	}
}
*/
// void saxpy(const int size, const float alpha, const float *x, const int incx, float *y, const int incy)
// {

// 	if ( (incx == 1) && (incy == 1) )
// 	{
//     for (int i = 0; i < size; ++i) {  // i < size corrige l'erreur
//         y[i] = y[i] + alpha * x[i];
//     }
// 	}
// 	else
// 	{
// 		int ix = 0;
// 		int iy = 0;
// 		for (int i=0; i<=size; ++i)
// 		{
// 			y[i] = y[i] + alpha * x[i];
// 			ix = ix + incx;
// 			iy = iy + incy;
// 		}
// 	}
// }
void saxpy(const int size, const float alpha, const float *x, const int incx, float *y, const int incy)
{
    // Vérification des pointeurs NULL
    if (x == NULL || y == NULL) {
        fprintf(stderr, "Erreur: pointeur NULL détecté dans saxpy\n");
        return;
    }

    if ( (incx == 1) && (incy == 1) )
    {
        for (int i = 0; i < size; ++i) {  // Correction de la borne de boucle
            y[i] = y[i] + alpha * x[i];
        }
    }
    else
    {
        int ix = 0;
        int iy = 0;
        for (int i = 0; i < size; ++i)  // Correction de la borne de boucle
        {
            y[iy] = y[iy] + alpha * x[ix]; // Correction du dépassement d'indice
            ix = ix + incx;
            iy = iy + incy;
        }
    }
}




/*
Exemple : 
Avant :
x = [1, 2, 3]
y = [4, 5, 6]

Apr�s saxpy(x, y, 1.0) :
y = [5, 7, 9]
*/




/* void dswap(const int size, double *x, const int incx, double *y, const int incy) */
/* {} */

/* void dcopy(const int size, const double *x, const int incx, double *y, const int incy) */
/* {} */

/* void daxpy(const int size, const double alpha, const double *x, const int incx, double *y, const int incy) */
/* {} */
