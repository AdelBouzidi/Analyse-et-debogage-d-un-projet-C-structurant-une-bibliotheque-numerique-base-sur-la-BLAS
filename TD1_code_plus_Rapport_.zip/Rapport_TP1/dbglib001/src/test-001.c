#include <stdio.h>
#include <cblas.h>

int main(int argc, char **argv)
{
  int Size;
  int *pSize = &Size;

  // printf("Entrer la taille des vecteurs (exemple 8): ");
  // scanf("%d", pSize);

  printf("Entrer la taille des vecteurs (exemple 8): ");
  if (scanf("%d", pSize) != 1) {
    fprintf(stderr, "Erreur: entrée invalide.\n");
    return 1;
  }





  printf(" **************************** %d \n", Size);
  printf(" **************************** %d \n", Size);
  printf(" **************************** %d \n", Size);
  printf(" **************************** %d \n", Size);
  printf(" **************************** %d \n", Size);
  
  
  // Vérifier si Size est valide
  if (Size <= 0) {
    printf("Erreur : La taille doit être > 0.\n");
    return 1;
  }
  //Si Size <= 0, le programme s'arrête avec un message d'erreur.



  // Création des vecteurs avec allocation mémoire
  float *sv1 = salloc(Size);
  float *sv2 = salloc(Size);
  float *sv3 = salloc(Size);
  //salloc(Size) alloue dynamiquement un tableau de Size éléments en mémoire.
  //sv1, sv2, sv3 sont trois vecteurs alloués dynamiquement.
  
  
  
  //Problème potentiel évité : Une allocation de mémoire peut échouer (manque de mémoire), d'où la vérification suivante :
  // Vérification de l’allocation mémoire
  // if (sv1 == NULL || sv2 == NULL || sv3 == NULL) {
  //   printf("Erreur : allocation mémoire échouée !\n");
  //   return 1;  // Arrêt du programme en cas d’erreur
  // }




  if (sv1 == NULL) {
    fprintf(stderr, "Erreur: allocation de sv1 échouée\n");
  }
  if (sv2 == NULL) {
      fprintf(stderr, "Erreur: allocation de sv2 échouée\n");
  }
  if (sv3 == NULL) {
      fprintf(stderr, "Erreur: allocation de sv3 échouée\n");
  }

  // Si une allocation a échoué, on libère les autres et on quitte
  if (sv1 == NULL || sv2 == NULL || sv3 == NULL) {
      if (sv1) sfree(sv1);
      if (sv2) sfree(sv2);
      if (sv3) sfree(sv3);
      return 1;
  }




  // Initialisation des Vecteurs
  sinit(Size, sv1, 1.0, 1.0);
  sinit(Size, sv2, 1.0, 1.0);
  //sinit() initialise chaque élément du vecteur avec une valeur de départ et un pas d'incrément.
  //Ex. pour sv1 avec val = 1.0 et incv = 1.0 :
  //[1.0, 2.0, 3.0, ..., Size]

  

  // Vérification avant d'utiliser scopy
  if (sv2 != NULL && sv3 != NULL)
    scopy(Size, sv2, 1, sv3, 1);
    //scopy() copie les éléments de sv2 dans sv3.


  printf("\n\n===============================\n");
  printf("Vectors before saxpy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);
  //sdump() affiche les éléments des vecteurs.


  // Vérification avant d'utiliser saxpy
  if (sv1 != NULL && sv3 != NULL)
    saxpy(Size, 1.0, sv1, 1, sv3, 1);
  //Opération saxpy() : sv3[i] + (1.0 * sv1[i]); saxpy() ajoute sv1 à sv3, pondéré par alpha = 1.0.




  printf("\n\n===============================\n");
  printf("Vectors after saxpy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);
  //On vérifie que sv3 a bien été mis à jour.
  

  // Vérification avant d'utiliser scopy
  if (sv3 != NULL && sv1 != NULL)
    scopy(Size, sv3, 1, sv1, 1);
    //sv1 prend les valeurs de sv3.


  printf("\n\n===============================\n");
  printf("Vectors after scopy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);

  // Libération mémoire pour éviter les fuites
  sfree(sv1);
  sfree(sv2);
  sfree(sv3);
  //Évite les fuites mémoire en libérant les allocations.
 

  return 0;
}



/*
#include <stdio.h>
#include <cblas.h>

int main(int argc, char **argv)
{
  int Size;
  // int *pSize =0;  ERR
  int *pSize = &Size;

  printf("Entrer la taille des vecteurs (exemple 8): ");
  scanf("%d", pSize);

  // Création des vecteurs
  float *sv1=salloc(Size);
  float *sv2=salloc(Size); 
  float *sv3=salloc(Size);


  // Initialisation des Vecteurs
  sinit(Size,sv1,1.0,1.0);
  sinit(Size,sv2,1.0,1.0);
  scopy(Size, sv2, 1, sv3, 1);

  printf("\n\n===============================\n");
  printf("Vectors before saxpy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);

  saxpy(Size, 1.0, sv1, 1, sv3, 1);

  printf("\n\n===============================\n");
  printf("Vectors after saxpy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);

  scopy(Size, sv3, 1, sv1, 1);
  printf("\n\n===============================\n");
  printf("Vectors after scopy computations : \n");
  sdump(Size, sv1);
  sdump(Size, sv2);
  sdump(Size, sv3);


  return 0;
}*/
